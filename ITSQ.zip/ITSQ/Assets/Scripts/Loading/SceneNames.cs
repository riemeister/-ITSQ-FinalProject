﻿using UnityEngine;
using System.Collections;

public class SceneNames {
	public const string MAIN_MENU_SCENE = "MainMenu";
	public const string IN_GAME_SCENE = "Ingame";
}
