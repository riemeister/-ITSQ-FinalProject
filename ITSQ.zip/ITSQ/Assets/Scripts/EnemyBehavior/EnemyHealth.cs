﻿using UnityEngine;
using System.Collections;

public class EnemyHealth : MonoBehaviour {

	public int startingHealth = 100;
	public int currentHealth = 5;
	public float sinkSpeed = 2.5f;

	GameObject player;
	Animator anim;
	bool isDead;

	void Awake(){
		anim = GetComponent<Animator> ();
		currentHealth = startingHealth;
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
//		if (isSinking) {
//			transform.Translate(-Vector3.up * sinkSpeed * Time.deltaTime);
//		}
	}

	public void TakeDamage(int amount){

		currentHealth -= amount;

		if (currentHealth <= 0 && !isDead) {
			Destroy(gameObject);
			Death();
		}
	}

	void Death(){
		isDead = true;
		anim.SetTrigger ("Die");
	}
}
