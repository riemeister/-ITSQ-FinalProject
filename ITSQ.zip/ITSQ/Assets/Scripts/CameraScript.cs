﻿using UnityEngine;
using System.Collections;

public class CameraScript : MonoBehaviour {

	GameObject player;

	private bool rotating = false;

	// Use this for initialization
	void Start () {
		player = GameObject.Find("Player");
	}
	
	// Update is called once per frame
	void Update () {
		transform.LookAt (player.transform);
		transform.position = new Vector3 (player.transform.position.x, player.transform.position.y+80, player.transform.position.z-200);
	}
}
