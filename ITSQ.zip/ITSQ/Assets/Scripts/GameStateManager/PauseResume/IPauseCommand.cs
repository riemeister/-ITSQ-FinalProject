﻿using UnityEngine;
using System.Collections;

public interface IPauseCommand  {
	void Pause();
}
