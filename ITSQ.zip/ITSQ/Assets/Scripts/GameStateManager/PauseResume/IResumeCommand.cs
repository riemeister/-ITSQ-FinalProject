﻿using UnityEngine;
using System.Collections;

public interface IResumeCommand {
	void Resume();
}
