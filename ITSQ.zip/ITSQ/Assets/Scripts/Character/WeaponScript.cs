﻿using UnityEngine;
using System.Collections;

public class WeaponScript : MonoBehaviour {
	public float speed = 20.0f;
	GameObject enemy;
	GameObject player;

	// Use this for initialization
	void Start () {
		this.StartCoroutine (this.DelayDestroy ());
		player = GameObject.FindGameObjectWithTag ("Player");
		enemy = GameObject.FindGameObjectWithTag ("Enemy");
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.forward * speed);

	}

	private IEnumerator DelayDestroy() {
		yield return new WaitForSeconds(2.0f); //TEMPORARY. Destroy projectile after 2.0 seconds. Should destroy projectile upon hit.
		GameObject.Destroy (this.gameObject);
	}

	void OnTriggerEnter(Collider col){
		if (col.gameObject.tag == "Enemy") {
			EnemyHealth eh = enemy.GetComponent<EnemyHealth>();
			PlayerControl pC = player.GetComponent<PlayerControl>();
			eh.TakeDamage(pC.currentDamage);
			Destroy(gameObject);
		}
	}
}