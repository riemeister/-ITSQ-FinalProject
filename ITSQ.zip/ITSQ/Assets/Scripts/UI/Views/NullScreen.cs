﻿using UnityEngine;
using System.Collections;

public class NullScreen : View {

	// Use this for initialization
	void Start () {
	
	}

}
